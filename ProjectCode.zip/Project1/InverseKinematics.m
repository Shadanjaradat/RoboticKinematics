clear all 
clc 

%DH Table 
%DH Parameter using toolbox
%L = Link([Theta d a alpha]) 'R' or 'P'
L1 = 5; L2 = 11; L3 = 12; L4=0; L5=11; 
L(1) = Link('d', L1, 'a', 0, 'alpha', pi/2);
L(2) = Link('d', 0, 'a', L2, 'alpha', 0);
L(3) = Link('d', 0, 'a', L3, 'alpha', 0);
L(4) = Link('d', 0, 'a', 0, 'alpha', pi/2);
L(5) = Link('d', L5, 'a', 0, 'alpha', 0);


%Define the robot 
Lynx = SerialLink(L);
Lynx.name = 'LynxmotionArm';


%Inverse_Kinematics // input xyz to get angles
mdl_puma560;
RPY = rpy2tr(0, 0, 45, 'deg');
T1 = transl(2, 2, 40) * RPY; % Z 38
T2 = transl(19, 4, 4) * RPY; % X 19
T3 = transl(4, 19, 5) * RPY; % Y 19
IK1 = Lynx.ikunc(T1); %displays angles
IK2 = Lynx.ikunc(T2);
IK3 = Lynx.ikunc(T3);
Lynx.teach(IK1)
pause(5)
Lynx.teach(IK2)
pause(5) 
Lynx.teach(IK3)

FK1 = Lynx.fkine(IK1); %displays matrix
FK2 = Lynx.fkine(IK2);
FK3 = Lynx.fkine(IK3);



